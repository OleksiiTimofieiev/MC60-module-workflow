
/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2013
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   main.c
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   This app demonstrates how to send AT command with RIL API, and transparently
 *   transfer the response through MAIN UART. And how to use UART port.
 *   Developer can program the application based on this example.
 * 
 ****************************************************************************/
#ifdef __CUSTOMER_CODE__

#include "custom_feature_def.h"
#include "ql_stdlib.h"
#include "ql_common.h"
#include "ql_type.h"
#include "ql_trace.h"
#include "ql_error.h"
#include "ql_uart.h"
#include "ql_gprs.h"
#include "ql_socket.h"
#include "ql_timer.h"
#include "ril_sim.h"
#include "ril_network.h"
#include "ril.h"
#include "ril_util.h"
#include "ril_telephony.h"
#include "ql_spi.h"
#include "ql_system.h"
#include "ql_gpio.h"

#define DEBUG_ENABLE 1
#if DEBUG_ENABLE > 0
#define DEBUG_PORT UART_PORT1
#define DBG_BUF_LEN 528
static char DBG_BUFFER[DBG_BUF_LEN];

#define APP_DEBUG(FORMAT, ...)                                                                                       \
{                                                                                                                \
    Ql_memset(DBG_BUFFER, 0, DBG_BUF_LEN);                                                                       \
    Ql_sprintf(DBG_BUFFER, FORMAT, ##__VA_ARGS__);                                                               \
    if (UART_PORT2 == (DEBUG_PORT))                                                                              \
    {                                                                                                            \
        Ql_Debug_Trace(DBG_BUFFER);                                                                              \
    }                                                                                                            \
    else                                                                                                         \
    {                                                                                                            \
        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT), (u8 *)(DBG_BUFFER), Ql_strlen((const char *)(DBG_BUFFER))); \
    }                                                                                                            \
}
#else
#define APP_DEBUG(FORMAT, ...)
#endif

/* input buffer params */
#define SERIAL_RX_BUFFER_LEN_SSL  2048
static  u8  m_RxBuf_Uart_SSL[SERIAL_RX_BUFFER_LEN_SSL];

/* SSL funcs */
void	dianostics_SSL(s32 code_of_error);
s32		send_AT_cmd_SSL(u8 *cmd, s32 *fun);

/* callback of send_AT_cmd_SSL */
s32		response_callback_SSL(char* line, u32 len, void* userData);

/* UART callback routines */
void	CallBack_UART_Hdlr_SSL(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara);
s32		ReadSerialPort_SSL(Enum_SerialPort port, /*[out]*/u8* pBuffer, /*[in]*/u32 bufLen);

/* SSL  routines */
void    gprs_connection_routine_SSL(void);
void    ssl_protocol_configuration(void);
void    connect_to_remote_server(void);
u8      detect_IP(u8 *line);

void    proc_main_task(s32 taskId)
{
    ST_MSG  msg;
    s32     ret;
    s32     func_result = RIL_AT_FAILED;

	APP_DEBUG("\n<--Open Debug Session.-->\r\n");

    Ql_UART_Register(UART_PORT1, CallBack_UART_Hdlr_SSL, NULL);
    Ql_UART_Open(UART_PORT1, 115200, FC_NONE);

    ret = Ql_UART_Register(VIRTUAL_PORT1, CallBack_UART_Hdlr_SSL, NULL);
    if (ret < QL_RET_OK)
    {
        Ql_Debug_Trace("Fail to register virtual port[%d], ret=%d\r\n", UART_PORT1, ret);
    }

    ret = Ql_UART_Open(VIRTUAL_PORT1, 115200, FC_NONE);
    if (ret < QL_RET_OK)
    {
        Ql_Debug_Trace("Fail to open virtual port[%d], ret=%d\r\n", UART_PORT1, ret);
    }

    /* system information */
    get_core();
    get_SDK();

	while (TRUE)
	{
        Ql_OS_GetMessage(&msg);

		switch (msg.message)
		{
			case MSG_ID_RIL_READY:
            {
				APP_DEBUG("<-- RIL is ready -->\r\n");
                Ql_RIL_Initialize();
				break ;
            }
            case MSG_ID_URC_INDICATION:
            {
                switch(msg.param1)
                {
                    case URC_GPRS_NW_STATE_IND:
                    {
                        APP_DEBUG("<-- GPRS Network Status: waiting for the connection -->\r\n");

                        if (msg.param2 == NW_STAT_REGISTERED)
                        {
                            APP_DEBUG("<-- GPRS Network Registered:%d -->\r\n", msg.param2);
                            
                            gprs_connection_routine_SSL();
                            ssl_protocol_configuration();
                            connect_to_remote_server();
                        }
                        break ;
                    }
                    default:
                        break ;
                }
            }
            default:
                break ;
		}
    }
}

void	dianostics_SSL(s32 code_of_error)
{
	if (code_of_error == RIL_AT_FAILED)
	{
		APP_DEBUG("RIL_AT_FAILED\r\n");
	}
	else if (code_of_error == RIL_AT_TIMEOUT)
	{
		APP_DEBUG("RIL_AT_TIMEOUT\r\n");
	}
	else if (code_of_error == RIL_AT_BUSY)
	{
		APP_DEBUG("RIL_AT_BUSY\r\n");
	}
	else if (code_of_error == RIL_AT_INVALID_PARAM)
	{
		APP_DEBUG("RIL_AT_INVALID_PARAM\r\n");
	}
	else if (code_of_error == RIL_AT_UNINITIALIZED)
	{
		APP_DEBUG("RIL_AT_UNINITIALIZED\r\n");
	}
}

u8      detect_IP(u8 *line)
{
    u8 i = 0;

    while (*line)
    {
        if (*line == '.')
            i++;
        line++;
    }
    return (i);
}

s32		response_callback_SSL(char* line, u32 len, void* userData) // el costello in func;
{
    Ql_UART_Write(UART_PORT1, (u8*)line, len);

    APP_DEBUG("line in callback -> %s\r\n", line);
    
    if (Ql_RIL_FindLine(line, len, "OK"))
    {  
        return  RIL_ATRSP_SUCCESS;
    }
    else if (detect_IP(line) == 3)
    {  
        APP_DEBUG("IP detected\r\n");
        return  RIL_ATRSP_SUCCESS;
    }
    else if (Ql_RIL_FindLine(line, len, "CONNECT"))
    {  
        APP_DEBUG("Connection established\r\n");
        return  RIL_ATRSP_SUCCESS;
    }
    else if (Ql_RIL_FindLine(line, len, "ERROR"))
    {  
        return  RIL_ATRSP_FAILED;
    }
    else if (Ql_RIL_FindString(line, len, "+CME ERROR"))
    {
        return  RIL_ATRSP_FAILED;
    }
    else if (Ql_RIL_FindString(line, len, "+CMS ERROR:"))
    {
        return  RIL_ATRSP_FAILED;
    }
    return RIL_ATRSP_CONTINUE; //continue wait
    // return  RIL_ATRSP_SUCCESS;
}

s32 	ReadSerialPort_SSL(Enum_SerialPort port, /*[out]*/u8* pBuffer, /*[in]*/u32 bufLen)
{
    s32 rdLen = 0;
    s32 rdTotalLen = 0;
    if (NULL == pBuffer || 0 == bufLen)
    {
        return -1;
    }
    Ql_memset(pBuffer, 0x0, bufLen);
    while (1)
    {
        rdLen = Ql_UART_Read(port, pBuffer + rdTotalLen, bufLen - rdTotalLen);
        if (rdLen <= 0)  // All data is read out, or Serial Port Error!
        {
            break;
        }
        rdTotalLen += rdLen;
        // Continue to read...
    }
    
    APP_DEBUG("Input to the port -> %s\r\n", pBuffer);

    if (rdLen < 0) // Serial Port Error!
    {
        APP_DEBUG("<--Fail to read from port[%d]-->\r\n", port);
        return -99;
    }
    return rdTotalLen;
}

void 	CallBack_UART_Hdlr_SSL(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara)
{
    switch (msg)
    {
    case EVENT_UART_READY_TO_READ:
        {
           s32 totalBytes = ReadSerialPort_SSL(port, m_RxBuf_Uart_SSL, sizeof(m_RxBuf_Uart_SSL));
           break;
        }
    case EVENT_UART_READY_TO_WRITE:
        break;
    default:
        break;
    }
}

void    get_core(void)
{
    s32 ret;
    u8 tmpbuf[100];
    
    Ql_memset(tmpbuf, 0x0, sizeof(tmpbuf));
    ret = Ql_GetCoreVer((u8*)tmpbuf, sizeof(tmpbuf));
    if(ret > 0)
    {
        APP_DEBUG("<--Core Version:%s-->\r\n", tmpbuf);
    }
    else
    {
        APP_DEBUG("<--Get Core Version Failure.-->\r\n");
    }
}

void    get_SDK(void)
{
    s32 ret;
    u8 tmpbuf[100];
    
    Ql_memset(tmpbuf, 0, sizeof(tmpbuf));
    ret = Ql_GetSDKVer((u8*)tmpbuf, sizeof(tmpbuf));
    if(ret > 0)
    {
        APP_DEBUG("<--SDK Version:%s.-->\r\n", tmpbuf);
    }else
    {
        APP_DEBUG("<--Get SDK Version Failure.-->\r\n");
    }
}

s32     send_AT_cmd_SSL(u8 *cmd, s32 *fun)
{
    *fun = 0;
    return Ql_RIL_SendATCmd(cmd, Ql_strlen(cmd), response_callback_SSL, NULL, 0);
}

void    gprs_connection_routine_SSL(void)
{
    s32     func_result = 0;

    APP_DEBUG("Set context 0 as foreground context.\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QIFGCNT=0\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("Select bearer type & configure APN.\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QICSGP=1,\"www.kyivstar.net\"\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("Register to TCP/IP stack\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QIREGAPP\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("PDP Context Activate.\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+CGACT=1\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("Activate GPRS Context\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QIACT\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }
    
    APP_DEBUG("Query local IP address.\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QILOCIP\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }
}

void    ssl_protocol_configuration(void)
{
    s32     func_result = 0;

    APP_DEBUG("Configure SSL version\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QSSLCFG=\"sslversion\",0,4\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("Configure server authentication and client authentication.\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QSSLCFG=\"seclevel\",0,0\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }

    APP_DEBUG("Configure cipher suite\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QSSLCFG=\"ciphersuite\",0,\"0XFFFF\"\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }
}

void    connect_to_remote_server(void)
{
    // command=1 <=> socket, 0 <=> SSL context index (0-5), 220.180.239.212 <=> IP of SSL server or URL,
    // 443 (https) | 80 (general http port) <=> port, connect mode=1 (1-transparent);

    s32     func_result = 0;

    APP_DEBUG("Connection to server request\r\n");
    if ((func_result = send_AT_cmd_SSL("AT+QSSLOPEN=1,0,\"172.217.20.174\",443,1\0", &func_result)) != RIL_AT_SUCCESS)
    {
        dianostics_SSL(func_result);
    }
}

#endif // __CUSTOMER_CODE__
